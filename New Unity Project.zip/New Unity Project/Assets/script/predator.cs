﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class predator : MonoBehaviour
{
    private GameObject[] chrs;
    public Text nigth;
    public int food;
    public GameObject enemy;
    public GameObject camera;
    private Vector3 spawn;
    public string act;
    private float speed = 4f;
    private gen stat;
    void Start()
    {
        food = 0;
        camera = GameObject.FindWithTag("MainCamera");
        stat = camera.GetComponent<gen>();
        refresh();
        spawn = gameObject.transform.position;
       
    }


    void Update()
    {
        /*  if (nigth.text == "ночь")
        {
            Debug.Log("ночь наступила");
            if(food < 40)
                Destroy(gameObject);
            refresh();
        }*/
        if(enemy != null && act == "еда")
        {
            trans(enemy.transform.position);
            if (transform.position == enemy.transform.position)
            {
                food += 50;
                Destroy(enemy);
                //stat.refresh_stat();
                act = "спать";
            }
        }
        else if (enemy == null && act == "еда")
        {
            refresh();
        }
        else if(act == "спать")
        {
            trans(spawn);
        }
    }

    void trans(Vector3 target)
    {
        transform.position = Vector3.MoveTowards(transform.position, target,
            speed * Time.deltaTime);
    }
    void refresh()
    {
        food = 0;
        act = "еда";
        chrs = GameObject.FindGameObjectsWithTag("ch");
        Vector3 min = new Vector3(0, 0, 0);
        for (int i = 0; i < chrs.Length; i++)
        {
            ch act = chrs[i].GetComponent<ch>();
            if (act.el == true)
            {
                enemy = chrs[i];
                break;
            }
            else 
            {
                var dis = transform.position - chrs[i].transform.position;
                if ((Mathf.Abs(dis.x) > Mathf.Abs(min.x)) && (Mathf.Abs(dis.y) > Mathf.Abs(min.y)))
                {
                    min = chrs[i].transform.position;
                    enemy = chrs[i];
                }
            }
        }
    }
}
