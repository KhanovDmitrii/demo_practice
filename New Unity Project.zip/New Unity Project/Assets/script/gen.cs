﻿using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using UnityEngine.UI;
using UnityEngine;

public class gen : MonoBehaviour
{

    private GameObject[] chrs;
    public Text scoreText;
    public Text d_o_n;
    public Text stats;
    public GameObject prot;  
    private GameObject[] enemy;
    private float speed = 4f;
    public GameObject prot_enemy;
    public GameObject env;
    private int el_stats = 0;
    void Start()
    {
        //spawn();
        InvokeRepeating("RunTimer", 1, 1);
        spawn();

        refresh_stat();
    
    }
    void Awake()    
    {

    }


    // Update is called once per frame
    void Update()
    {
    }
    void RunTimer() {
        scoreText.text = (int.Parse(scoreText.text) - 1).ToString();
        if (scoreText.text == "0")
        {
            Debug.Log("ноль");
            //par();
            d_o_n.text = "ночь";
           
            scoreText.text = "30";

            dead();
            par_2();
            refresh();
            refresh_stat();

            d_o_n.text = "день";

        }
    }

    void spawn()
    {
        GameObject generate_env = Instantiate<GameObject>(env);
        GameObject new_cl;
        generate_env.name = "water";
        generate_env.transform.position = new Vector3((float) Random.Range(-9, 9), (float) Random.Range(-6, 6), 0);
        generate_env.tag = "env";
        
        int b = Random.Range(4, 10);
        for (int i = 0; i < b; i++)
        {
            new_cl = Instantiate<GameObject>(prot);
            
            new_cl.name = "s1 (" + i.ToString() + ")";
            new_cl.transform.position = new Vector3((float) Random.Range(-20, 20), (float) Random.Range(-15, 15), 0);
            new_cl.tag = "ch";
        }
        
        GameObject generate_predator = Instantiate<GameObject>(prot_enemy);
        generate_predator.name = "preadtor";
        generate_predator.transform.position = new Vector3((float) Random.Range(-9, 9), (float) Random.Range(-6, 6), 0);
        generate_predator.tag = "enemy";
        
        
    }
    void par_2()
    {
        chrs = GameObject.FindGameObjectsWithTag("ch");
        for (int i = 0; i < chrs.Length; i++)
        {
            ch partner_1 = chrs[i].GetComponent<ch>();
            GameObject close_ch = null;
            if (partner_1.act == "размножаться")
            {
                Vector3 min = new Vector3(9999, 999, 9999);
                for (int j = i + 1; j < chrs.Length; j++)
                {
                    var dis = chrs[i].transform.position - chrs[j].transform.position;
                    ch activetes = chrs[i].GetComponent<ch>();
                    //Debug.Log(activetes.food + " " + activetes.act);
                    if ((Mathf.Abs(dis.x) < Mathf.Abs(min.x)) && (Mathf.Abs(dis.y) < Mathf.Abs(min.y)) &&
                        (activetes.food == 100)
                        && (activetes.act == "размножаться") && (activetes.el == false))
                    {
                        min = chrs[j].transform.position;
                        close_ch = chrs[j];
                    }
                }

                if (close_ch != null)
                {
                    razm(chrs[i], close_ch, i );
                }
            }
        }
        
    }

    public void refresh_stat()
    {
        int el_stats = 0;
        chrs = GameObject.FindGameObjectsWithTag("ch");
        for (int i = 0; i < chrs.Length; i++)
        {
            ch stats_count = chrs[i].GetComponent<ch>();
            Debug.Log(stats_count.food + " " + stats_count.el);
            if (stats_count.el == true)
                el_stats+=1;
        }

        Debug.Log("Я тут");
        string text = "На момент нового цикла было:" + "\r\n" + "Кл-во бактерий: " + chrs.Length.ToString() + "\r\n"
                      + "Кол-во больных из них: " + el_stats + "\r\n" 
                      + "Кол-во амеб: 1";
        stats.text = text;
        el_stats = 0;
    }


    void dead()
    {
        chrs = GameObject.FindGameObjectsWithTag("ch");
        for (int i = 0; i < chrs.Length; i++)
        {
            ch act = chrs[i].GetComponent<ch>();
            if (act.el || act.food < 100)
            {
                Destroy(chrs[i]);
            }
        }
        enemy = GameObject.FindGameObjectsWithTag("enemy");
        for (int i = 0; i < enemy.Length; i++)
        {
            predator act_en = enemy[i].GetComponent<predator>();
            if (act_en.food == 0)
            {
                Destroy(enemy[i]);
            }
        }
    }
    void refresh()
    { 
        chrs = GameObject.FindGameObjectsWithTag("ch");
        for (int i = 0; i < chrs.Length; i++)
        {
            ch act = chrs[i].GetComponent<ch>();
            act.food = 0;
                act.partner = null;
                act.act = "еда";
        }
        enemy = GameObject.FindGameObjectsWithTag("enemy");
        for (int i = 0; i < enemy.Length; i++)
        {
            predator act_en = enemy[i].GetComponent<predator>();
            act_en.enemy = null;
            act_en.act = "еда";
        }
    }
    void razm(GameObject p_1, GameObject p_2, int col)
    {
        
        //par_trans(p_1, p_2);
        ch partner_1 = p_1.GetComponent<ch>();
        ch partner_2 = p_2.GetComponent<ch>();
        //if (p_1.transform.position == p_2.transform.position)
        //{
            GameObject new_cl = Instantiate<GameObject>(prot);
            
            new_cl.name = "s1 (" + (chrs.Length + (col + 1)).ToString() + ")";
            new_cl.transform.position = new Vector3(partner_1.transform.position.x + 0.4f,
                partner_1.transform.position.y + 0.4f, 0);
            //partner_1.food = 0;
            //partner_2.food = 0;
            new_cl.tag = "ch";
            partner_1.partner = null;
            partner_2.partner = null;
            partner_1.act = "спать";
            partner_2.act = "спать";
        //}
    }

    void par_trans(GameObject p1, GameObject p2)
    {
        p1.transform.position = Vector3.MoveTowards(p1.transform.position, p2.gameObject.transform.position,
            speed * Time.deltaTime);
    }
}
