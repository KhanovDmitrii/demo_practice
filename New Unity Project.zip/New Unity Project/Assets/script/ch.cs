﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class ch : MonoBehaviour
{

    private GameObject[] ev;
    private Vector3 spawn; 
    public int food = 0;
    private Vector3 pos_env;
    private float speed = 2.5f;
    public string act;
    public GameObject partner = null;
    public bool el;
    public Text nght;
    private SpriteRenderer spritr_render;
    public Sprite el_sprite; //Resources.Load<Sprite>("Assets/s3.png");//Load<Sprite>("../s3.jpg");

    private void Awake()
    {
        int b = Random.Range(0, 10);
        if (b > 7)
        {
            el = true;
            //  spritr_render.sprite. = el_sprite;
            gameObject.GetComponent<SpriteRenderer>().sprite = el_sprite;
        }
        else
        {
            el = false;
        }
    }

    void Start()
    {
        var l1 = FindObjectsOfType(typeof(Text));
        nght = (Text)l1[1];
        ev = GameObject.FindGameObjectsWithTag("env");
        //house = GameObject.FindWithTag("house");
        spawn = transform.position;
        act = "еда";
       // el_sprite = Resources.Load<Sprite>("Assets/s3.png");//Load<Sprite>("../s3.jpg");
    }

    void Update()
    {

        if (food < 100 && act == "еда")
        {
            transform.position = Vector3.MoveTowards(transform.position, ev[0].transform.position,
                                       speed * Time.deltaTime);
            if (transform.position == ev[0].transform.position)
            {
                food += 50;
                act = "спать";
            }
        }

        else if (act == "спать")
        {
            transform.position = Vector3.MoveTowards(transform.position, spawn,
                speed * Time.deltaTime);
            
            if (transform.position == spawn)
            {
                if(food < 100)
                    act = "еда";
                else if(food == 100)
                {
                    act = "размножаться";
//                    SearchPass();
                    
                }
            }

            if ((nght.text == "ночь") && (el))
            {
                Destroy(gameObject);
            }
        }
    }
}

