#import "UADSMetaData.h"

@interface UADSPlayerMetaData : UADSMetaData

- (void)setServerId:(NSString *)serverId;

@end